package com.rentmitra.rmproduct.controller;

public class ProductImageControllerTest {
}
