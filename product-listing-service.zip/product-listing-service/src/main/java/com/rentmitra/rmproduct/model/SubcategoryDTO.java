package com.rentmitra.rmproduct.model;

public class SubcategoryDTO {
    private Integer subcategoryId;
    private String name;


    public Integer getSubcategoryId() {
        return subcategoryId;
    }

    public void setSubcategoryId(Integer subcategoryId) {
        this.subcategoryId = subcategoryId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
