package com.rentmitra.rmproduct.request;

import lombok.Data;

@Data
public class SubcategoryRequest {
    private  String name;
}

