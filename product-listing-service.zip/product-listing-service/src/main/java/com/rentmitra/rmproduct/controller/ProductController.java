package com.rentmitra.rmproduct.controller;

import com.rentmitra.rmproduct.model.CategoryDTO;
import com.rentmitra.rmproduct.model.Product;
import com.rentmitra.rmproduct.model.ProductAttributes;
import com.rentmitra.rmproduct.request.CategoryRequest;
import com.rentmitra.rmproduct.request.ProductAttributRequest;
import com.rentmitra.rmproduct.request.ProductRequest;
import com.rentmitra.rmproduct.service.CategoryService;
import com.rentmitra.rmproduct.service.ProductlistingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import com.rentmitra.rmproduct.model.ProductDto;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/products")
public class ProductController {

    @Autowired
    private ProductlistingService productService;

    @Autowired
    private CategoryService categoryService;

    @GetMapping("/filter")
    public ResponseEntity<List<Product>> filterProducts(
            @RequestParam Integer categoryId,
            @RequestParam Integer subcategoryId) {
        List<Product> products = productService.getProductsByCategoryAndSubcategory(categoryId, subcategoryId);
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    @GetMapping("/categories")
    public ResponseEntity<List<CategoryDTO>> getAllCategories() {
        List<CategoryDTO> categories = categoryService.getAllCategoriesWithSubcategories();
        return new ResponseEntity<>(categories, HttpStatus.OK);
    }

    @GetMapping("/category-names")
    public ResponseEntity<List<String>> getAllCategoryNames() {
        List<String> categoryNames = categoryService.getAllCategoryNames();
        return new ResponseEntity<>(categoryNames, HttpStatus.OK);
    }

    @GetMapping("/subcategories")
    public ResponseEntity<List<String>> getSubcategoriesByCategoryName(@RequestParam String categoryName) {
        List<String> subcategories = categoryService.getSubcategoriesByCategoryName(categoryName);
        return new ResponseEntity<>(subcategories, HttpStatus.OK);
    }

    @GetMapping("/productsbysubcategory/{subcategoryName}")
    public ResponseEntity<List<Product>> getProductsBySubcategoryName(@PathVariable String subcategoryName) {
        List<Product> products = productService.getProductsBySubcategoryName(subcategoryName);
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    @GetMapping("/getByBrand")
    public ResponseEntity<List<ProductDto>> getByBrandApi(@RequestParam String brand){
      List<ProductDto> productDtoList =   productService.getByBrand(brand);
        return new ResponseEntity<>(productDtoList,HttpStatus.OK);
    }


    @PostMapping("/addproduct")
    public ResponseEntity<String> addProduct(@RequestBody ProductRequest productRequest) {
        List<ProductAttributRequest> attributes = productRequest.getAttributes();

        attributes.forEach(System.out::println);
        productService.addProduct(productRequest);

        return new ResponseEntity<>("Product added successfully", HttpStatus.CREATED);
    }

    @GetMapping("/filterProductByRentType")
    public ResponseEntity<List<Product>> filterProductsByRentType(@RequestParam String rentType) {
        List<Product> products = productService.getProductsByRentType(rentType);
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    @GetMapping("/filter-products-by-price")
    public ResponseEntity<List<ProductDto>> filterProductsByCategorySubcategoryAndPrice(
            @RequestParam Integer categoryId,
            @RequestParam Integer subcategoryId,
            @RequestParam Double minPrice,
            @RequestParam Double maxPrice) {

        List<ProductDto> products = productService.filterProducts(categoryId, subcategoryId, minPrice, maxPrice);
        return new ResponseEntity<>(products, HttpStatus.OK);
    }

    @DeleteMapping("deleteproduct/{productId}/category/{categoryId}/subcategory/{subcategoryId}")
    public ResponseEntity<String> deleteProduct(
            @PathVariable Integer productId,
            @PathVariable Integer categoryId,
            @PathVariable Integer subcategoryId) {

        productService.deleteProduct(productId, categoryId, subcategoryId);
        return ResponseEntity.ok("Product deleted successfully.");
    }

    @PostMapping("/addcategory")
    public ResponseEntity<String> addcategoryApi(@RequestBody CategoryRequest categoryRequest){
         return new ResponseEntity<>( categoryService.addCategory(categoryRequest),HttpStatus.CREATED);
    }


}
