package com.rentmitra.rmproduct.service;

import com.rentmitra.rmproduct.exceptions.CategoryNotFoundException;
import com.rentmitra.rmproduct.model.Category;
import com.rentmitra.rmproduct.model.CategoryDTO;
import com.rentmitra.rmproduct.model.Subcategory;
import com.rentmitra.rmproduct.model.SubcategoryDTO;
import com.rentmitra.rmproduct.repository.CategoryRepository;
import com.rentmitra.rmproduct.repository.SubcategoryRepository;
import com.rentmitra.rmproduct.request.CategoryRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class CategoryService {
    @Autowired
    private CategoryRepository categoryRepository;

    @Autowired
    private SubcategoryRepository subcategoryRepository;

    public List<CategoryDTO> getAllCategoriesWithSubcategories() {
        List<Category> categories = categoryRepository.findAll();
        if (categories.isEmpty()) {
            throw new CategoryNotFoundException("No categories found");
        }
        return categories.stream().map(category -> {
            CategoryDTO categoryDTO = new CategoryDTO();
            categoryDTO.setCategoryId(category.getCategoryId());
            categoryDTO.setName(category.getName());

            // Fetch subcategories for the category
            List<Subcategory> subcategories = category.getSubcategories();
            List<SubcategoryDTO> subcategoryDTOs = subcategories.stream().map(subcategory -> {
                SubcategoryDTO subcategoryDTO = new SubcategoryDTO();
                subcategoryDTO.setSubcategoryId(subcategory.getSubcategoryId());
                subcategoryDTO.setName(subcategory.getName());
                return subcategoryDTO;
            }).collect(Collectors.toList());

            categoryDTO.setSubcategories(subcategoryDTOs);
            return categoryDTO;
        }).collect(Collectors.toList());
    }

    public List<String> getAllCategoryNames() {
        List<Category> categories = categoryRepository.findAll();
        if (categories.isEmpty()) {
            throw new CategoryNotFoundException("No categories found");
        }
        return categories.stream()
                .map(Category::getName)
                .collect(Collectors.toList());
    }

    public List<String> getSubcategoriesByCategoryName(String categoryName) {
        Category category = categoryRepository.findByName(categoryName)
                .orElseThrow(() -> new CategoryNotFoundException("Category not found with name: " + categoryName));

        return category.getSubcategories().stream()
                .map(Subcategory::getName)
                .collect(Collectors.toList());
    }

    public String addCategory(CategoryRequest categoryRequest){
        Category category = new Category();
        category.setName(categoryRequest.getName());
        categoryRepository.save(category);
        List<Subcategory> subcategories = categoryRequest.getSubcategories().stream()
                .map(subcategoryDTO -> {
                    Subcategory subcategory = new Subcategory();
                    subcategory.setName(subcategoryDTO.getName());
                    subcategory.setCategory(category);
                    return subcategory;
                })
                .collect(Collectors.toList());
        subcategoryRepository.saveAll(subcategories);
        category.setSubcategories(subcategories);
        categoryRepository.save(category);
        return "!Success category added";
    }



}