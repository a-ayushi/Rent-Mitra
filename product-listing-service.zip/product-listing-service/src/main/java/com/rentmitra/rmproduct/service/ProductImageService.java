package com.rentmitra.rmproduct.service;

import com.rentmitra.rmproduct.exceptions.ResourceNotFoundException;
import com.rentmitra.rmproduct.model.Product;
import com.rentmitra.rmproduct.model.ProductImageDTO;
import com.rentmitra.rmproduct.model.ProductImages;
import com.rentmitra.rmproduct.repository.ProductImageRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import javax.sql.rowset.serial.SerialBlob;
import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class ProductImageService {

     @Autowired
    private ProductImageRepository productImageRepository;

     @Autowired
     private ProductlistingService productlistingService;


    public List<ProductImageDTO> saveImages(List<MultipartFile> files, Integer product_id) {

        Product product =	productlistingService.getById(product_id);

        List<ProductImageDTO> savedImages = new ArrayList<>();
        try {
            for(MultipartFile file : files) {
                ProductImages image = new ProductImages();
                image.setFileName(file.getOriginalFilename());
                image.setFileType(file.getContentType());
                image.setImage(new SerialBlob(file.getBytes()));
                image.setProduct(product);

                String builddownloadUrl = " /api/product/image/download/";
                ProductImages savedimage = 	productImageRepository.save(image);
                String downloadUrl = builddownloadUrl+savedimage.getId();
                savedimage.setDownloadurl(builddownloadUrl+savedimage.getId());
                productImageRepository.save(savedimage);

                ProductImageDTO imagedto = new ProductImageDTO();
                imagedto.setId(savedimage.getId());
                imagedto.setFileName(savedimage.getFileName());
                imagedto.setDownloadUrl(savedimage.getDownloadurl());

                savedImages.add(imagedto);

            }
        }
        catch (SQLException | IOException e) {
            e.printStackTrace();
        }
        return savedImages;
    }

    public ProductImages getImageById(Integer id) {
        return productImageRepository.findById(id)
                .orElseThrow(()->{throw new ResourceNotFoundException("Image Not Found With Id"+id);});
    }

    public void deleteImageByid(Integer imageid){
        productImageRepository.findById(imageid)
                .ifPresentOrElse(productImageRepository::delete,()->{throw new ResourceNotFoundException(
                        "! Image not found ");});
    }

    public ProductImageDTO updateImageById(MultipartFile file,Integer imageid){
        ProductImageDTO productImageDTO = new ProductImageDTO();
         productImageRepository.findById(imageid).ifPresentOrElse(image->{
            try{
                image.setFileName(file.getName());
                image.setFileType(file.getContentType());
                image.setImage(new SerialBlob(file
                        .getBytes()));
                productImageRepository.save(image);
                productImageDTO.setFileName(image.getFileName());
                productImageDTO.setDownloadUrl(image.getDownloadurl());

            } catch (Exception e) {
                throw new RuntimeException(e);
            }

        },()->{throw new ResourceNotFoundException("!Image not exists");});
      return productImageDTO;

    }

}
