package com.rentmitra.rmproduct.repository;

import com.rentmitra.rmproduct.model.ProductAttributes;
import org.springframework.data.jpa.repository.JpaRepository;

public interface IProductAttributeRepository extends JpaRepository<ProductAttributes,Integer> {
}
