package com.rentmitra.rmproduct.controller;

import com.rentmitra.rmproduct.model.ProductImageDTO;
import com.rentmitra.rmproduct.model.ProductImages;
import com.rentmitra.rmproduct.response.ApiResponse;
import com.rentmitra.rmproduct.service.ProductImageService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ByteArrayResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;

@RestController
@RequestMapping("/api/product/image")
public class ProductImageController {

     @Autowired
    private ProductImageService productImageService;


     @PostMapping("/upload")
    public ResponseEntity<ApiResponse> uploadImages(@RequestParam List<MultipartFile> files,
                                                    @RequestParam("id") Integer product_id){

        try {
            List<ProductImageDTO> imagelist  =	 productImageService.saveImages(files, product_id);
            return new ResponseEntity<ApiResponse>(new ApiResponse("Upload Success !", imagelist),
                    HttpStatus.OK);
        } catch (Exception e) {
            return new ResponseEntity<>(
                    new ApiResponse("Upload Failed!", e.getMessage()),
                    HttpStatus.INTERNAL_SERVER_ERROR
            );

        }
    }


    @Transactional
    @GetMapping("/download/{imageId}")
    public ResponseEntity<ByteArrayResource> downloadImage(@PathVariable Integer imageId) {
        try {
            ProductImages image = productImageService.getImageById(imageId);
            if (image == null || image.getImage() == null) {
                System.out.println("in if");
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body(null);
            }

            ByteArrayResource resource = new ByteArrayResource(
                    image.getImage().getBytes(1, (int) image.getImage().length())
            );

            return ResponseEntity.ok()
                    .contentType(org.springframework.http.MediaType.parseMediaType(image.getFileType()))
                    .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + image.getFileName() + "\"")
                    .body(resource);

        } catch (Exception e) {
            System.out.println("inside catch"+e.getMessage());
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }




    @DeleteMapping("/removeimagebyid")
    public ResponseEntity<ApiResponse> deleteImageByIdApi(@RequestParam("id") Integer image_id){
           try {
               productImageService.deleteImageByid(image_id);
               return new ResponseEntity<>(new ApiResponse("! delete Success",null),HttpStatus.OK);
           } catch (Exception e) {
               return new ResponseEntity<>(new ApiResponse("! delete Failed",e.getMessage()),HttpStatus.NOT_FOUND);
           }

    }

    @PutMapping("/updateImagebyid")
    public ResponseEntity<ApiResponse> updateImageApi(@RequestParam MultipartFile file,@RequestParam Integer id){
         try{
          ProductImageDTO productImageDTO =    productImageService.updateImageById(file,id);
          return new ResponseEntity<>(new ApiResponse("!Update Success",
                  productImageDTO.getDownloadUrl()),HttpStatus.OK);

         } catch (Exception e) {
             return new ResponseEntity<>(new ApiResponse("! Update failed",
                     e.getMessage()),HttpStatus.OK);
         }
    }


}
