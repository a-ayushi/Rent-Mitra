package com.rentmitra.rmproduct.request;

import lombok.Data;

@Data
public class ProductAttributRequest {
    private String attributeName;
    private String attributValue;
}
