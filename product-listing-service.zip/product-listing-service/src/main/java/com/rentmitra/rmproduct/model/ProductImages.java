package com.rentmitra.rmproduct.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.sql.Blob;

@Data
@Entity
@Table(name="product_images")
@NoArgsConstructor
@AllArgsConstructor
public class ProductImages {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private  Integer id;

    private  String fileName;
    private String fileType;

    @JsonIgnore
    @Lob
    private Blob image;
    private String downloadurl;

    @JsonIgnore
    @ManyToOne
    @JoinColumn(name="product_id")
    private Product product;

}
