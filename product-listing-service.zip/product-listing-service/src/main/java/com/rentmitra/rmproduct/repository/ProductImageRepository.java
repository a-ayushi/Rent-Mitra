package com.rentmitra.rmproduct.repository;

import com.rentmitra.rmproduct.model.ProductImages;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductImageRepository extends JpaRepository<ProductImages,Integer> {
}
