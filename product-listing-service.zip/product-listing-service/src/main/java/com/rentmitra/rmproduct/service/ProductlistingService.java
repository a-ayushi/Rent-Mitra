package com.rentmitra.rmproduct.service;

import com.rentmitra.rmproduct.model.*;
import com.rentmitra.rmproduct.repository.CategoryRepository;
import com.rentmitra.rmproduct.repository.IProductAttributeRepository;
import com.rentmitra.rmproduct.repository.ProductRepository;
import com.rentmitra.rmproduct.request.ProductAttributRequest;
import com.rentmitra.rmproduct.request.ProductRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.sql.Timestamp;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;
import java.util.stream.Collectors;


@Service
public class ProductlistingService {

    @Autowired
    private IProductAttributeRepository iProductAttributeRepository;

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryRepository categoryRepository;

    public List<Product> getProductsByCategoryAndSubcategory(Integer categoryId, Integer subcategoryId) {
        return productRepository.findByCategoryIdAndSubcategoryId(categoryId, subcategoryId);
    }

    public List<Product> getProductsBySubcategoryName(String subcategoryName) {
        // Find the subcategory by name
        Subcategory subcategory = categoryRepository.findAll()
                .stream()
                .flatMap(category -> category.getSubcategories().stream())
                .filter(sc -> sc.getName().equalsIgnoreCase(subcategoryName))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Subcategory not found: " + subcategoryName));

        // Get products for that subcategory
        return productRepository.findBySubcategoryId(subcategory.getSubcategoryId());
    }

    public void addProduct(ProductRequest productdto) {
        // Validate category and subcategory existence
        Category category = categoryRepository.findById(productdto.getCategoryId())
                .orElseThrow(() -> new RuntimeException("Category not found"));

        Subcategory subcategory = category.getSubcategories().stream()
                .filter(sc -> sc.getSubcategoryId().equals(productdto.getSubcategoryId()))
                .findFirst()
                .orElseThrow(() -> new RuntimeException("Subcategory not found under the selected category"));



        // Create a new Product entity
        Product product = new Product();
        product.setName(productdto.getName());
        product.setBrand(productdto.getBrand());
        product.setCategoryId(category.getCategoryId());
        product.setSubcategoryId(subcategory.getSubcategoryId());
        product.setRentType(productdto.getRentType());
        product.setRentBasedOnType(productdto.getRentBasedOnType());
        product.setAddress(productdto.getAddress());
        product.setNavigation(productdto.getNavigation());
        product.setMessage(productdto.getMessage());
        product.setMobileNumber(productdto.getMobileNumber());
        product.setCreatedAt(new Timestamp(System.currentTimeMillis()));
        product.setUpdatedAt(new Timestamp(System.currentTimeMillis()));
        List<ProductAttributRequest> attributeRequests = productdto.getAttributes();
        if (attributeRequests != null) {
            attributeRequests.forEach(attr -> {
                ProductAttributes productAttribute = new ProductAttributes();
                productAttribute.setAttributeName(attr.getAttributeName());
                productAttribute.setAttributValue(attr.getAttributValue());
                product.addAttribute(productAttribute);
            });
        }
        productRepository.save(product);
    }

    public List<Product> getProductsByRentType(String rentType) {
        return productRepository.findByRentType(rentType);
    }

    public Product getById(Integer id) {
        Optional<Product> product = productRepository.findById(id);
        if (product.isPresent()) {
            return product.get(); // Retrieve the product
        } else {
            throw new NoSuchElementException("Product with ID " + id + " not found.");
        }
    }

    public List<ProductDto> filterProducts(Integer categoryId, Integer subcategoryId, Double minPrice, Double maxPrice) {
        List<Product> products = productRepository.findProductsByCategoryAndSubcategoryAndPriceRange(categoryId, subcategoryId, minPrice, maxPrice);

        // Map Product entities to ProductDTO
        return products.stream()
                .map(product -> new ProductDto(
                        product.getName(),
                        product.getBrand(),
                        product.getCategoryId(),
                        product.getSubcategoryId(),
                        product.getRentType(),
                        product.getRentBasedOnType(),
                        product.getAddress(),
                        product.getNavigation(),
                        product.getMessage(),
                        product.getMobileNumber(),
                        product.getAttributes()
                        ))
                .collect(Collectors.toList());
    }

    public List<ProductDto> getByBrand(String brand) {
        List<Product> products = productRepository.findByBrand(brand);
        // Map Product entities to ProductDTO
        return products.stream()
                .map(product -> new ProductDto(
                        product.getName(),
                        product.getBrand(),
                        product.getCategoryId(),
                        product.getSubcategoryId(),
                        product.getRentType(),
                        product.getRentBasedOnType(),
                        product.getAddress(),
                        product.getNavigation(),
                        product.getMessage(),
                        product.getMobileNumber(),
                        product.getAttributes()
                ))
                .collect(Collectors.toList());
    }


    public void deleteProduct(Integer productId, Integer categoryId, Integer subcategoryId) {
        Product product = productRepository.findByProductIdAndCategoryIdAndSubcategoryId(productId, categoryId, subcategoryId)
                .orElseThrow(() -> new RuntimeException(
                        String.format("Product with ID %d not found in Category ID %d and Subcategory ID %d",
                                productId, categoryId, subcategoryId)));

        productRepository.delete(product);
    }




}
